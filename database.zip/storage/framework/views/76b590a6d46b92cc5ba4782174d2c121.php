<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.104.2">
    <title>Signin Template · Bootstrap v5.2</title>
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
  </head>
  <body class="d-flex flex-column min-vh-100 text-center">
  <?php if(auth()->guard()->check()): ?>                       
    <div class="container">
        <header class="d-flex flex-wrap justify-content-between py-3 mb-4 border-bottom">
            <a href="<?php echo e(url('/')); ?>" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
                <span class="fs-4">Logo</span>
            </a>  
            <div class="dropdown text-end">
                <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle active" data-bs-toggle="dropdown" aria-expanded="false">Hi  <?php echo e(optional(auth()->user())->first_name); ?>            
                </a>
                <ul class="dropdown-menu text-small">
                <li><a class="dropdown-item" href="#">Edit Profile</a></li>
                <li><a class="dropdown-item" href="#">Download TMP</a></li> 
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?php echo e(url('/logout')); ?>">Sign out</a></li>
                </ul>
            </div>
        </header>      
    </div>
  <?php endif; ?>
  <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>   

    <?php if(session()->has('message')): ?>
        <div class="alert alert-<?php echo e(session('type') ?? 'success'); ?>">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>    

  <?php echo $__env->yieldContent('content'); ?>  
    <footer class="footer mt-auto py-3 bg-body-tertiary">
      <div class="container">
        <span class="text-body-secondary"><p class="mt-5 mb-3 text-muted">&copy; 2024</p></span>
      </div>
    </footer>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
<?php /**PATH F:\xamp\htdocs\tmp\resources\views/layouts/master.blade.php ENDPATH**/ ?>