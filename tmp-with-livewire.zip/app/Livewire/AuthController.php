<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\User as Users;

class AuthController extends Component
{
    public $user_id, $first_name, $last_name, $email, $password, $role, $industry, $age, $country;
    public $isLogin = true;

    public function render()
    {
        return view('livewire.auth-controller');
    }

    public function ragister(){
        $this->isLogin = false;
    }
    public function login(){
        $this->isLogin = true;
    }
}
