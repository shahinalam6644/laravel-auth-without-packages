
<!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<!--[if BLOCK]><![endif]--><?php if(session()->has('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<!--[if BLOCK]><![endif]--><?php if($isLogin): ?>
    <?php echo $__env->make('livewire.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('livewire.ragister', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->


<?php /**PATH F:\xamp\htdocs\tmp\resources\views/livewire/auth-controller.blade.php ENDPATH**/ ?>