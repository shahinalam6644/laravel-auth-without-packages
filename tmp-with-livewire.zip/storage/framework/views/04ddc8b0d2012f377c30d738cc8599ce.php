<main class="form-signin w-100 m-auto">
    <form>
      <img class="mb-4" src="assets/brand/bootstrap-logo.svg" alt="" width="72" height="57">
      <h1 class="h3 mb-3 fw-normal">Register!</h1>

      <div class="form-floating">
        <input type="text" class="form-control" id="floatingInput" placeholder="First Name">
        <label for="floatingInput">First Name</label>
      </div>
      <div class="form-floating">
        <input type="text" class="form-control" id="floatingPassword" placeholder="Last Name">
        <label for="floatingPassword">Last Name</label>
      </div>
      <div class="form-floating">
        <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
        <label for="floatingInput">Email address</label>
      </div>
      <div class="form-floating">
        <input type="text" class="form-control" id="floatingInput" placeholder="Industry">
        <label for="floatingInput">Industry</label>
      </div>    
      <div class="form-floating">
        <input type="text" class="form-control" id="floatingInput" placeholder="Age">
        <label for="floatingInput">Age</label>
      </div>    
      <div class="form-floating">
        <input type="text" class="form-control" id="floatingInput" placeholder="Country">
        <label for="floatingInput">Country</label>
      </div>
      <div class="form-floating">
        <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
        <label for="floatingPassword">Password</label>
      </div>

      <div class="checkbox mb-3">
        <label>
          <input type="checkbox" value="remember-me"> Remember me
        </label>
      </div>
      <button class="w-100 btn btn-lg btn-primary" type="submit" wire:click.prevent="login()">Sign Up</button>
      <p class="mt-5 mb-3 text-muted">&copy; 2024</p>
    </form>
  </main>  <?php /**PATH F:\xamp\htdocs\tmp\resources\views/livewire/ragister.blade.php ENDPATH**/ ?>